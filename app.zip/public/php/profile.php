<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Profile Page - AllJapan</title>
    <link rel="stylesheet" href="../css/profile.css">
</head>
<body>
    <img src="../images/logo-hitam.png" alt="">
</body>
</html>