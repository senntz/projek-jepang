<?php
$koneksi= mysqli_connect('localhost','root','','login') or die('connection failed');
?>