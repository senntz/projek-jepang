<?php

?>

<footer>
    <img src="..\\images\\logo-putih.png" alt="" id="logo-footer">
    <div id="menu-footer">
        <a href="home.php">Home</a>
        <a href="destination.php">Destination</a>
        <a href="about.php">About</a>
    </div>
    <div id="contact-footer">
        <img src="..\\images\\footer-twit.png" alt="" id="contfoot-twit">
        <img src="..\\images\\footer-link.png" alt="" id="contfoot-link">
        <img src="..\\images\\footer-ig.png" alt="" id="contfoot-ig">
    </div>
    <span>Copyright © 2024 all-JAPAN All Rights Reserved.</span>
</footer>