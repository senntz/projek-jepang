<?php

    header("Location:./php/home.php");

?>